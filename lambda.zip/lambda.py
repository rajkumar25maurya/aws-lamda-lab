def lambda_handler(event , context):
    print("Hello Raj from Terraform")
    return"Hello Raj from Terraform"