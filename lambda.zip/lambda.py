def lambda_handler(event , context):
    print("Hello Raj from Terraform ipraxa")
    return"Hello Raj from Terraform ipraxa"